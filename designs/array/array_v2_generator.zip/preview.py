"""Preview pictures for make_array_v2.py: each FPC from its copper side, and the
finished stack seen from the FPC 1 side (FPC 1 mirrored over FPC 2)."""

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon as MPoly, Rectangle

from make_array_v2 import ELEMENT, HOLE, element

CU = '#c8771e'
OPEN = '#2e9e5b'
EDGE_C = '#202020'


def draw(ax, g, mirror=False, alpha=1.0, copper=CU, show_open=True, lw_scale=1.0):
    s = -1 if mirror else 1
    polys = [g['outline']] if g['outline'].geom_type == 'Polygon' else list(g['outline'].geoms)
    for poly in polys:
        for ring in [poly.exterior, *poly.interiors]:
            xs, ys = zip(*ring.coords)
            ax.plot([s * x for x in xs], ys, color=EDGE_C, lw=0.8 * lw_scale, alpha=alpha)
    if g['stiffener']:
        x0, y0, x1, y1 = g['stiffener']
        ax.add_patch(Rectangle((min(s * x0, s * x1), y0), abs(x1 - x0), y1 - y0, color='#4a78c2', alpha=0.18 * alpha, lw=0))
    for pts, w, net in g['tracks']:
        xs, ys = zip(*pts)
        ax.plot([s * x for x in xs], ys, color=copper, lw=w * lw_scale * 6, alpha=alpha, solid_capstyle='round')
    for pid, x, y, w, h, net, margin in g['pads']:
        ax.add_patch(Rectangle((s * x - w / 2, y - h / 2), w, h, color=copper, alpha=alpha, lw=0))
        if show_open and margin < 0:
            ax.add_patch(Rectangle((s * x - w / 2 - margin, y - h / 2 - margin), w + 2 * margin, h + 2 * margin,
                                   fill=False, ec=OPEN, lw=0.6, alpha=alpha))
    for x0, y0, x1, y1 in g['mask_rects']:
        ax.add_patch(Rectangle((min(s * x0, s * x1), y0), abs(x1 - x0), y1 - y0, fill=False, ec=OPEN, lw=0.8, ls='--'))
    for x, y in g['holes']:
        ax.add_patch(Circle((s * x, y), HOLE / 2, fill=False, ec=EDGE_C, lw=0.8))


def frame(ax, title, xlim, ylim):
    ax.set_xlim(*xlim)
    ax.set_ylim(ylim[1], ylim[0])
    ax.set_aspect('equal')
    ax.set_title(title, fontsize=9)
    ax.tick_params(labelsize=7)
    ax.grid(True, lw=0.3, alpha=0.4)


def render(built, out):
    out.mkdir(exist_ok=True)
    for version in ('2-1', '2-2'):
        f1, f2 = built[(version, 'FPC1')], built[(version, 'FPC2')]
        y_t = min(p[2] for p in f1['pads'] if p[0].startswith('G'))
        fig = plt.figure(figsize=(16, 10.5))
        gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.15])
        # whole FPC 1, turned sideways
        ax = fig.add_subplot(gs[0, :])
        polys = [f1['outline']] if f1['outline'].geom_type == 'Polygon' else list(f1['outline'].geoms)
        for poly in polys:
            xs, ys = zip(*poly.exterior.coords)
            ax.fill(ys, xs, color='#f2d36b', ec=EDGE_C, lw=0.6)
        b = f1['outline'].bounds
        ax.set_xlim(b[1] - 3, b[3] + 3)
        ax.set_aspect('equal')
        ax.set_title(f'v{version} FPC 1, whole length (tail left, array right) - {b[3] - b[1]:.0f} x {b[2] - b[0]:.0f} mm', fontsize=9)
        ax.tick_params(labelsize=7)
        # tail
        ax = fig.add_subplot(gs[1, 0])
        draw(ax, f1)
        y_tip = f1['y_tip']
        for pid, x, y, w, h, net, margin in f1['pads']:
            if pid in ('J1', 'J2', 'J31', 'J32'):
                ax.text(x, y_tip - 0.6, f'{pid[1:]}\n{net}', ha='center', va='bottom', fontsize=6)
        ax.text(0, y_tip + 6.2, 'blue = PI stiffener (back side)\ndashed green = coverlay window', ha='center', fontsize=6.5)
        frame(ax, 'FPC 1 tail, copper side\n(pin 1 = EL0 at the right; goes into J1001 copper side down)', (-10, 10), (y_tip - 3, y_tip + 12))
        # array zone, each FPC from its copper side
        bottom = f1['outline'].bounds[3] + 1
        for col, g, title in ((1, f1, 'FPC 1 array zone, copper side'), (2, f2, 'FPC 2, copper side')):
            ax = fig.add_subplot(gs[1, col])
            draw(ax, g)
            for pid, x, y, w, h, net, margin in g['pads']:
                if pid.startswith('E'):
                    ax.text(x, y, net.replace('GND', 'G'), ha='center', va='center', fontsize=5.5, color='white')
            frame(ax, title, (-22.5, 22.5), (y_t - 4.5, bottom))
        fig.tight_layout()
        fig.savefig(out / f'v{version}_layout.png', dpi=160)
        plt.close(fig)

        # stack seen from the FPC 1 side: FPC 1 mirrored, over FPC 2
        fig, ax = plt.subplots(figsize=(9, 7))
        draw(ax, f2, copper='#7a7a7a', alpha=0.55, show_open=False)
        draw(ax, f1, mirror=True, alpha=0.9)
        for k in range(16):
            x, y = element(k)
            ax.add_patch(Rectangle((-x - ELEMENT / 2, y - ELEMENT / 2), ELEMENT, ELEMENT, fill=False, ec='#3050c0', lw=1.0, ls='--'))
            ax.text(-x, y, f'EL{k}', ha='center', va='center', fontsize=7, color='#3050c0', weight='bold')
        frame(ax, f'v{version} stack seen from the FPC 1 side (ribbon up)\norange = FPC 1 signal (mirrored), grey = FPC 2 ground, dashed blue = 3x3 mm elements',
              (-22.5, 22.5), (y_t - 4.5, bottom))
        fig.tight_layout()
        fig.savefig(out / f'v{version}_stack.png', dpi=170)
        plt.close(fig)
