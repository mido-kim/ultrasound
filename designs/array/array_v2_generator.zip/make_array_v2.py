"""Element array v2: two single-layer FPCs per version, for JLCPCB flex.

FPC 1 (signal): gold-finger tail for the main board's J1001 (Molex 54132-3297,
32 pins, 0.5 mm, bottom contact; odd pins EL0-EL15, even pins GND), a 254 mm
ribbon with signal and ground alternating, a fan-out, a row of ground transfer
pads, and one signal pad per element. Its ground traces end at the transfer pads.
FPC 2 (ground): the matching transfer pads, and one ground trace per element
that runs on the same path as that element's signal trace on FPC 1.

Stack (looking down from the FPC 1 side, ribbon pointing up):
    FPC 1, copper facing down  /  elements + ACF  /  FPC 2, copper facing up
The transfer pads of FPC 1 and FPC 2 meet face to face and carry ground across.

Element map, same view: 8 columns x 2 rows, 4 mm pitch, column pairs.
First (leftmost) column EL0 near / EL1 far, then EL2 / EL3, ... EL14 / EL15.
"Near" is the row next to the ribbon.

Versions:
  2-1  straight traces, rectangular outline with margins, 4 alignment holes
  2-2  wavy legs, outline cut close to the traces (islands under the elements)

Coordinates: mm, KiCad style (y grows downward), drawn from each FPC's copper
side. FPC 1's copper side is the stack seen from below, so its x is mirrored:
column c of FPC 1 sits at x = 14 - 4c, of FPC 2 at x = 4c - 14.

Run:  python make_array_v2.py      (needs shapely, matplotlib, KiCad 9)
"""

import json
import math
import shutil
import subprocess
import uuid
import zipfile
from pathlib import Path

from shapely.geometry import LineString, Polygon, box
from shapely.ops import unary_union

HERE = Path(__file__).resolve().parent
KICAD_CLI = r'C:\Program Files\KiCad\9.0\bin\kicad-cli.exe'
MAIN_PRO = HERE.parent / 'pcb_v5' / 'us_control_v5.4_main' / 'us_control_v5_main.kicad_pro'

# ---------------------------------------------------------------- fixed by parts and JLC
PITCH = 4.0            # element pitch, both directions
ELEMENT = 3.0          # STEMINC SMPL3W3T05410, 3 x 3 x 0.55 mm
N_COL = 8
FFC_PITCH = 0.5        # Molex 54132
TAIL_HALF = 8.25       # tail width 0.5 (N + 1) = 16.5 mm
FINGER_W = 0.35        # Molex: 0.35 +0.04/-0.03
FINGER_LEN = 4.3
FINGER_SETBACK = 0.35  # copper back from the tip (JLC: >= 0.2, DRC edge rule 0.3)
COVER_OPEN = FINGER_SETBACK + 4.0   # exposed finger length 4.0 (Molex: >= 3.5)
STIFFENER_LEN = 7.0    # Molex: >= 5.5 from the tip
TIP_R = 0.3            # Molex: R0.3 at the tip corners
RIBBON_LEN = 254.0     # ~10 in of plain ribbon
FAN_LEN = 20.0
RIBBON_W = 0.25
TRACE_W = 0.2
EDGE = 0.3             # JLC: copper to outline
STRIP_HALF = TRACE_W / 2 + EDGE + 0.02  # half width of a cut-out trace strip (0.42)
GPAD = (1.0, 2.0)      # ground transfer pad copper (w, h)
MASK_IN = 0.1          # coverlay overlaps pad copper by this much (coverlay-defined pads)
HOLE = 1.0             # alignment holes, non-plated

VERSIONS = {
    '2-1': dict(y_t=-6.5, pad=2.6, island=None, wavy=False, half_w=21.0, bottom=10.5,
                holes=[(-19, None), (19, None), (-19, 8.0), (19, 8.0)]),
    '2-2': dict(y_t=-10.5, pad=1.8, island=2.44, wavy=True, half_w=20.5, bottom=None,
                holes=[(-19, None), (19, None)]),
}
WAVE_A = 0.5           # mm, peak
WAVE_PERIODS = 2


def x_col(c):          # FPC 1 copper view
    return 14.0 - PITCH * c


def sig_x(k):          # signal k at the transfer row
    return 15.5 - 2.0 * k


def gnd_x(k):          # ground transfer pad k
    return 14.5 - 2.0 * k


def rib_x(pin):        # connector pin 1..32 in the ribbon (FPC 1 copper view: pin 1 at the right)
    return 7.75 - FFC_PITCH * (pin - 1)


def element(k):
    return x_col(k // 2), (0.0 if k % 2 == 0 else PITCH)


def mirror(pts):
    return [(-x, y) for x, y in pts]


def leg(xa, ya, xb, yb, wavy):
    if not wavy:
        return [(xa, ya), (xb, yb)]
    n = 200
    pts = []
    for i in range(n + 1):
        t = i / n
        x = xa + (xb - xa) * t + WAVE_A * math.sin(math.pi * t) * math.sin(2 * math.pi * WAVE_PERIODS * t)
        pts.append((x, ya + (yb - ya) * t))
    return pts


def array_path(k, v):
    """Signal k on FPC 1 from y_d (just below the transfer row) into its element pad."""
    c = k // 2
    near = k % 2 == 0
    half = (v['island'] or v['pad']) / 2
    y_d = v['y_t'] + 2.0
    y_b = -half - 0.8
    xc = x_col(c)
    pad_half = v['pad'] / 2
    if near:
        return leg(sig_x(k), y_d, xc, y_b, v['wavy']) + [(xc, -pad_half + 0.5)]
    # far row: down the gap left of the near element, then into the far pad from the side
    return leg(sig_x(k), y_d, xc - 2.0, y_b, v['wavy']) + [(xc - 2.0, PITCH), (xc - pad_half + 0.5, PITCH)]


def build(version, which):
    v = VERSIONS[version]
    y_t = v['y_t']
    y_d = y_t + 2.0
    y_fe = y_t - 3.0
    y_fs = y_fe - FAN_LEN
    y_rib = y_fs - RIBBON_LEN
    y_tip = y_rib - STIFFENER_LEN
    g = dict(tracks=[], pads=[], holes=[], mask_rects=[], stiffener=None, texts=[], nets=[])
    holes = [(x, y if y is not None else y_t) for x, y in v['holes']]
    g['holes'] = holes

    if which == 'FPC1':
        g['nets'] = [f'EL{k}' for k in range(16)] + [f'GND{k}' for k in range(16)]
        for pin in range(1, 33):
            k = (pin - 1) // 2
            net = f'EL{k}' if pin % 2 else f'GND{k}'
            x0 = rib_x(pin)
            g['pads'].append((f'J{pin}', x0, y_tip + FINGER_SETBACK + FINGER_LEN / 2, FINGER_W, FINGER_LEN, net, 0.0))
            x1 = sig_x(k) if pin % 2 else gnd_x(k)
            ribbon = [(x0, y_tip + FINGER_SETBACK + FINGER_LEN - 0.3), (x0, y_fs)]
            g['tracks'].append((ribbon, RIBBON_W, net))
            if pin % 2:
                g['tracks'].append(([(x0, y_fs), (x1, y_fe), (x1, y_d)] + array_path(k, v), TRACE_W, net))
            else:
                g['tracks'].append(([(x0, y_fs), (x1, y_fe), (x1, y_t - GPAD[1] / 2 + 0.4)], TRACE_W, net))
        for k in range(16):
            g['pads'].append((f'G{k}', gnd_x(k), y_t, GPAD[0], GPAD[1], f'GND{k}', -MASK_IN))
            ex, ey = element(k)
            g['pads'].append((f'E{k}', ex, ey, v['pad'], v['pad'], f'EL{k}', -MASK_IN))
        g['mask_rects'].append((-TAIL_HALF - 1, y_tip - 1, TAIL_HALF + 1, y_tip + COVER_OPEN))
        g['stiffener'] = (-TAIL_HALF, y_tip, TAIL_HALF, y_tip + STIFFENER_LEN)
    else:
        g['nets'] = [f'GND{k}' for k in range(16)]
        for k in range(16):
            gx = -gnd_x(k)
            g['pads'].append((f'G{k}', gx, y_t, GPAD[0], GPAD[1], f'GND{k}', -MASK_IN))
            ex, ey = element(k)
            g['pads'].append((f'E{k}', -ex, ey, v['pad'], v['pad'], f'GND{k}', -MASK_IN))
            path = [(gx, y_t + GPAD[1] / 2 - 0.4), (gx, y_t + GPAD[1] / 2), (-sig_x(k), y_d)] + mirror(array_path(k, v))[1:]
            g['tracks'].append((path, TRACE_W, f'GND{k}'))

    # ---------------------------------------------------------------- outline
    hw = v['half_w']
    if v['island'] is None:
        rect = box(-hw, y_fe, hw, v['bottom'])
        if which == 'FPC1':
            outline = unary_union([tail(y_tip, y_fs + 0.01), Polygon([(-TAIL_HALF, y_fs), (TAIL_HALF, y_fs), (hw, y_fe), (-hw, y_fe)]), rect])
        else:
            outline = rect
    else:
        half = v['island'] / 2
        parts = [box(-hw, y_fe, hw, y_t + 2.4)]          # transfer band, with hole tabs
        for k in range(16):
            path = array_path(k, v)
            if which == 'FPC2':
                path = mirror(path)
            parts.append(LineString(path).buffer(STRIP_HALF, quad_segs=8))
            ex, ey = element(k)
            if which == 'FPC2':
                ex = -ex
            parts.append(box(ex - half, ey - half, ex + half, ey + half))
        if which == 'FPC1':
            fan_half = sig_x(0) + STRIP_HALF + 0.1
            parts += [tail(y_tip, y_fs + 0.01), Polygon([(-TAIL_HALF, y_fs), (TAIL_HALF, y_fs), (fan_half, y_fe + 0.01), (-fan_half, y_fe + 0.01)])]
        outline = unary_union(parts).simplify(0.002)
    g['outline'] = outline

    if version == '2-1':
        side = 'SIGNAL (FPC 1)' if which == 'FPC1' else 'GROUND (FPC 2)'
        g['texts'].append((f'ARRAY v2-1  {side}  copper side', 0.0, 9.0, 0.8))
        for c in range(N_COL):
            x = x_col(c) if which == 'FPC1' else -x_col(c)
            g['texts'].append((f'{2 * c}/{2 * c + 1}', x, 7.4, 0.8))
    g['y_tip'] = y_tip
    return g


def tail(y_tip, y_end):
    """Tail and ribbon, 16.5 mm wide, R0.3 at the two tip corners."""
    r, h = TIP_R, TAIL_HALF
    pts = [(-h, y_end), (-h, y_tip + r)]
    for i in range(1, 9):
        a = math.pi + (math.pi / 2) * i / 8
        pts.append((-h + r + r * math.cos(a), y_tip + r + r * math.sin(a)))
    for i in range(0, 9):
        a = 1.5 * math.pi + (math.pi / 2) * i / 8
        pts.append((h - r + r * math.cos(a), y_tip + r + r * math.sin(a)))
    pts.append((h, y_end))
    return Polygon(pts)


# ---------------------------------------------------------------- KiCad files

def U():
    return str(uuid.uuid4())


def kicad_pcb(g, name, offset):
    ox, oy = offset
    P = lambda x, y: f'{x + ox:.4f} {y + oy:.4f}'
    nets = {n: i + 1 for i, n in enumerate(g['nets'])}
    out = [HEADER.replace('@PAPER@', '"User" 130 340')]
    out.append('\t(net 0 "")')
    out += [f'\t(net {i} "{n}")' for n, i in nets.items()]
    # pads
    fp = [f'\t(footprint "array_v2:{name}_pads" (layer "F.Cu") (uuid "{U()}") (at {P(0, 0)})',
          f'\t\t(property "Reference" "P1" (at 0 0 0) (layer "F.SilkS") (hide yes) (uuid "{U()}") (effects (font (size 1 1) (thickness 0.15))))',
          f'\t\t(property "Value" "{name} pads" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "{U()}") (effects (font (size 1 1) (thickness 0.15))))',
          '\t\t(attr smd board_only exclude_from_pos_files exclude_from_bom)']
    for pid, x, y, w, h, net, margin in g['pads']:
        fp.append(f'\t\t(pad "{pid}" smd rect (at {x:.4f} {y:.4f}) (size {w:.4f} {h:.4f}) (layers "F.Cu" "F.Mask") '
                  f'(net {nets[net]} "{net}") (solder_mask_margin {margin}) (uuid "{U()}"))')
    fp.append('\t)')
    out += fp
    if g['holes']:
        hp = [f'\t(footprint "array_v2:{name}_holes" (layer "F.Cu") (uuid "{U()}") (at {P(0, 0)})',
              f'\t\t(property "Reference" "H1" (at 0 0 0) (layer "F.SilkS") (hide yes) (uuid "{U()}") (effects (font (size 1 1) (thickness 0.15))))',
              f'\t\t(property "Value" "alignment holes" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "{U()}") (effects (font (size 1 1) (thickness 0.15))))',
              '\t\t(attr board_only exclude_from_pos_files exclude_from_bom)']
        for x, y in g['holes']:
            hp.append(f'\t\t(pad "" np_thru_hole circle (at {x:.4f} {y:.4f}) (size {HOLE} {HOLE}) (drill {HOLE}) (layers "*.Cu" "*.Mask") (uuid "{U()}"))')
        hp.append('\t)')
        out += hp
    for pts, w, net in g['tracks']:
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            if abs(x1 - x0) < 1e-6 and abs(y1 - y0) < 1e-6:
                continue
            out.append(f'\t(segment (start {P(x0, y0)}) (end {P(x1, y1)}) (width {w}) (layer "F.Cu") (net {nets[net]}) (uuid "{U()}"))')
    polys = [g['outline']] if g['outline'].geom_type == 'Polygon' else list(g['outline'].geoms)
    for poly in polys:
        for ring in [poly.exterior, *poly.interiors]:
            pts = ' '.join(f'(xy {P(x, y)})' for x, y in list(ring.coords)[:-1])
            out.append(f'\t(gr_poly (pts {pts}) (stroke (width 0.05) (type solid)) (fill no) (layer "Edge.Cuts") (uuid "{U()}"))')
    for x0, y0, x1, y1 in g['mask_rects']:
        out.append(f'\t(gr_rect (start {P(x0, y0)}) (end {P(x1, y1)}) (stroke (width 0) (type solid)) (fill yes) (layer "F.Mask") (uuid "{U()}"))')
    if g['stiffener']:
        x0, y0, x1, y1 = g['stiffener']
        out.append(f'\t(gr_rect (start {P(x0, y0)}) (end {P(x1, y1)}) (stroke (width 0.1) (type solid)) (fill yes) (layer "User.1") (uuid "{U()}"))')
        out.append(f'\t(gr_text "PI STIFFENER 0.225 mm, NON-COPPER SIDE, {STIFFENER_LEN:g} mm FROM TIP" (at {P(x1 + 2, (y0 + y1) / 2)} 90) (layer "User.1") (uuid "{U()}") '
                   '(effects (font (size 1 1) (thickness 0.15))))')
    for text, x, y, size in g['texts']:
        out.append(f'\t(gr_text "{text}" (at {P(x, y)} 0) (layer "F.Cu") (uuid "{U()}") (effects (font (size {size} {size}) (thickness 0.12))))')
    out.append(')')
    return '\n'.join(out) + '\n'


HEADER = '''(kicad_pcb
\t(version 20241229)
\t(generator "array_v2_gen")
\t(generator_version "9.0")
\t(general
\t\t(thickness 0.11)
\t\t(legacy_teardrops no)
\t)
\t(paper @PAPER@)
\t(layers
\t\t(0 "F.Cu" signal)
\t\t(2 "B.Cu" signal)
\t\t(9 "F.Adhes" user "F.Adhesive")
\t\t(11 "B.Adhes" user "B.Adhesive")
\t\t(13 "F.Paste" user)
\t\t(15 "B.Paste" user)
\t\t(5 "F.SilkS" user "F.Silkscreen")
\t\t(7 "B.SilkS" user "B.Silkscreen")
\t\t(1 "F.Mask" user)
\t\t(3 "B.Mask" user)
\t\t(17 "Dwgs.User" user "User.Drawings")
\t\t(19 "Cmts.User" user "User.Comments")
\t\t(21 "Eco1.User" user "User.Eco1")
\t\t(23 "Eco2.User" user "User.Eco2")
\t\t(25 "Edge.Cuts" user)
\t\t(27 "Margin" user)
\t\t(31 "F.CrtYd" user "F.Courtyard")
\t\t(29 "B.CrtYd" user "B.Courtyard")
\t\t(35 "F.Fab" user)
\t\t(33 "B.Fab" user)
\t\t(39 "User.1" user "Stiffener")
\t)
\t(setup
\t\t(pad_to_mask_clearance 0)
\t\t(allow_soldermask_bridges_in_footprints no)
\t\t(tenting front back)
\t)'''


def kicad_pro(name):
    base = json.loads(MAIN_PRO.read_text(encoding='utf-8'))
    board = base['board']
    ds = board['design_settings']
    ds['rules'].update(min_copper_edge_clearance=EDGE, min_clearance=0.12, min_track_width=0.15,
                       min_hole_clearance=0.25, min_text_height=0.8)
    ds['drc_exclusions'] = []
    for rule in ('lib_footprint_issues', 'lib_footprint_mismatch', 'footprint_type_mismatch',
                 'solder_mask_bridge', 'silk_overlap', 'silk_over_copper', 'silk_edge_clearance'):
        ds['rule_severities'][rule] = 'ignore'
    default = next(c for c in base['net_settings']['classes'] if c['name'] == 'Default')
    default.update(clearance=0.14, track_width=TRACE_W)
    return json.dumps({
        'board': board,
        'meta': {'filename': f'{name}.kicad_pro', 'version': base['meta']['version']},
        'net_settings': {'classes': [default], 'meta': base['net_settings']['meta'],
                         'net_colors': None, 'netclass_assignments': None, 'netclass_patterns': []},
    }, indent=2)


def cli(*args):
    r = subprocess.run([KICAD_CLI, *args], capture_output=True, text=True, encoding='utf-8', errors='replace')
    if r.returncode not in (0, 5):     # 5: DRC found violations, read from the report
        raise RuntimeError(f'kicad-cli {args[:3]} failed: {r.stdout}\n{r.stderr}')
    return r


def export(version, which, g):
    name = f'array_v{version}_{which}_{"signal" if which == "FPC1" else "ground"}'
    d = HERE / f'v{version}_{which}'
    if d.exists():
        shutil.rmtree(d)
    (d / 'gerber').mkdir(parents=True)
    pcb = d / f'{name}.kicad_pcb'
    pcb.write_text(kicad_pcb(g, name, (65, 312)), encoding='utf-8')
    (d / f'{name}.kicad_pro').write_text(kicad_pro(name), encoding='utf-8')
    report = d / 'drc.json'
    cli('pcb', 'drc', '--format', 'json', '--severity-all', '-o', str(report), str(pcb))
    drc = json.loads(report.read_text(encoding='utf-8'))
    problems = [(x['type'], x['severity'], x['description']) for x in drc.get('violations', [])]
    problems += [('unconnected', 'error', x['description']) for x in drc.get('unconnected_items', [])]
    layers = 'F.Cu,F.Mask,Edge.Cuts' + (',User.1' if g['stiffener'] else '')
    cli('pcb', 'export', 'gerbers', '--layers', layers, '--no-x2', '-o', str(d / 'gerber'), str(pcb))
    cli('pcb', 'export', 'drill', '--format', 'excellon', '--excellon-separate-th', '--excellon-units', 'mm',
        '-o', str(d / 'gerber') + '\\', str(pcb))
    for f in (d / 'gerber').iterdir():   # name the stiffener file so JLC can't miss it
        if 'User_1' in f.name or 'Stiffener' in f.name:
            f.rename(f.with_name(f'{name}-Stiffener_PI_0.225mm{f.suffix}'))
    z = HERE / f'{name}_JLC.zip'
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in sorted((d / 'gerber').iterdir()):
            # no plated holes on a single-layer FPC, so the empty PTH drill file stays out
            if f.suffix.lower() in ('.gbr', '.gtl', '.gts', '.gm1', '.gko', '.drl') and not f.name.endswith('-PTH.drl'):
                zf.write(f, f.name)
    b = g['outline'].bounds
    return name, problems, (b[2] - b[0], b[3] - b[1]), sorted(n for n in zipfile.ZipFile(z).namelist())


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    built = {}
    for version in VERSIONS:
        for which in ('FPC1', 'FPC2'):
            g = build(version, which)
            built[(version, which)] = g
            name, problems, size, files = export(version, which, g)
            print(f'{name}: {size[0]:.1f} x {size[1]:.1f} mm, DRC {len(problems)} issue(s); {", ".join(files)}')
            for p in problems[:20]:
                print('   ', p)
    import preview
    preview.render(built, HERE / 'previews')
