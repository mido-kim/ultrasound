"""Element array v2-3: v2-2 with smaller element pads, wavy far-row traces, and
the ACF ground transfer row farther from the elements.

Changes from v2-2 (everything else comes from make_array_v2.py unchanged: tail,
ribbon, fan-out, transfer pads, element map, 4 mm pitch, outline cut to traces):
  - element pads 1.2 mm copper / 1.0 mm coverlay opening, 1.84 mm islands
  - far-row traces wave in the gaps between elements (±0.35 mm, 2 periods)
  - legs to the array wave ±0.6 mm, 3 periods
  - transfer pads 13 mm from the near-row elements (8 mm in v2-2)

Run:  python make_array_v2_3.py      (writes only the v2-3 files)
"""

import math
import sys

import make_array_v2 as base
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from preview import CU, draw, frame

PAD = 1.2
ISLAND = PAD + 2 * (base.EDGE + 0.02)        # 1.84
ELEMENT_EDGE_TO_PADS = 13.0                   # near-row element edge to the transfer pads
LEG_A, LEG_PERIODS = 0.6, 3
FAR_A, FAR_PERIODS = 0.35, 2

base.VERSIONS['2-3'] = dict(
    y_t=-(base.ELEMENT / 2 + ELEMENT_EDGE_TO_PADS + base.GPAD[1] / 2),   # -15.5
    pad=PAD, island=ISLAND, wavy=True, half_w=20.5, bottom=None,
    holes=[(-19, None), (19, None)], v23=True)


def wave(xa, ya, xb, yb, amp, periods, n=240):
    """From (xa, ya) to (xb, yb) with a sine wave that fades in and out at the ends."""
    pts = []
    for i in range(n + 1):
        t = i / n
        x = xa + (xb - xa) * t + amp * math.sin(math.pi * t) * math.sin(2 * math.pi * periods * t)
        pts.append((x, ya + (yb - ya) * t))
    return pts


_v2_path = base.array_path


def array_path(k, v):
    if not v.get('v23'):
        return _v2_path(k, v)
    c = k // 2
    xc = base.x_col(c)
    y_d = v['y_t'] + 2.0
    y_b = -v['island'] / 2 - 0.8
    tip = -v['pad'] / 2 + 0.35          # where a trace ends inside its pad
    if k % 2 == 0:
        return wave(base.sig_x(k), y_d, xc, y_b, LEG_A, LEG_PERIODS) + [(xc, tip)]
    return (wave(base.sig_x(k), y_d, xc - 2.0, y_b, LEG_A, LEG_PERIODS)
            + wave(xc - 2.0, y_b, xc - 2.0, base.PITCH, FAR_A, FAR_PERIODS)[1:]
            + [(xc + tip, base.PITCH)])


base.array_path = array_path            # build() looks it up by name


def render(built, out):
    f1, f2 = built['FPC1'], built['FPC2']
    y_t = base.VERSIONS['2-3']['y_t']
    bottom = f1['outline'].bounds[3] + 1
    fig, axes = plt.subplots(1, 2, figsize=(15, 8))
    for ax, g, title in ((axes[0], f1, 'v2-3 FPC 1 array zone, copper side'), (axes[1], f2, 'v2-3 FPC 2, copper side')):
        draw(ax, g)
        for pid, x, y, w, h, net, margin in g['pads']:
            if pid.startswith('E'):
                ax.text(x, y + 1.3, net.replace('GND', 'G'), ha='center', va='center', fontsize=5.5)
        frame(ax, title, (-22.5, 22.5), (y_t - 4.5, bottom))
    fig.tight_layout()
    fig.savefig(out / 'v2-3_layout.png', dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 9))
    draw(ax, f2, copper='#7a7a7a', alpha=0.55, show_open=False)
    draw(ax, f1, mirror=True, alpha=0.9)
    for k in range(16):
        x, y = base.element(k)
        ax.add_patch(Rectangle((-x - base.ELEMENT / 2, y - base.ELEMENT / 2), base.ELEMENT, base.ELEMENT, fill=False, ec='#3050c0', lw=1.0, ls='--'))
        ax.text(-x, y + 1.15, f'EL{k}', ha='center', va='center', fontsize=6.5, color='#3050c0', weight='bold')
    frame(ax, 'v2-3 stack seen from the FPC 1 side (ribbon up)\norange = FPC 1 signal (mirrored), grey = FPC 2 ground, dashed blue = 3x3 mm elements',
          (-22.5, 22.5), (y_t - 4.5, bottom))
    fig.tight_layout()
    fig.savefig(out / 'v2-3_stack.png', dpi=170)
    plt.close(fig)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    built = {}
    for which in ('FPC1', 'FPC2'):
        g = base.build('2-3', which)
        built[which] = g
        name, problems, size, files = base.export('2-3', which, g)
        print(f'{name}: {size[0]:.1f} x {size[1]:.1f} mm, DRC {len(problems)} issue(s); {", ".join(files)}')
        for p in problems[:20]:
            print('   ', p)
    render(built, base.HERE / 'previews')
